<!--
START OF: draft.md
Purpose: Write temporary 'drafts' or ideas you think might be lost if not documented
Update Frequency: Each time a new idea or note comes to mind and don't know where it belongs.
Location: docs/draft.md
-->

# Draft

Write you thoughts you think might be lost or don't know where they belong

- [ ] example draft.


<!-- END OF: draft.md -->
