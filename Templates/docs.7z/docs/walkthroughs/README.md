<!--
START OF: docs/walkthroughs/README.md
Pupose: Provide a comprehensive overview of the walkthroughs.
Update Ferquency: Whenever a new walkthrought is added.
Location: docs/walkthroughs/README.md
-->

# Walkthroughs

Providing small bite-sized instruction on each feature for the busy reviewer.

## List

1. [ ] **Template Walkthrough** ([template.md](template.md))
   _Description:_ Giving you insights on how to write walkthroughs.
   _Time Created:_ <2025-06-15 Sun>

<!-- END OF: docs/walkthroughts/README.md -->
