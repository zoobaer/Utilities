<!--
START OF: performance-research-template.md
Purpose: Perform research on performance and write their implications for project decisions.
Update Frequency: Each time a performance question needs answers.
Location: docs/research/performance/performance-research-template.md
-->

# Database Research Template

statement

### Research

Aspects to be researched

#### Links

##### Insights Gained

##### What was the impact of the linked resource



## Desicion


<!-- END OF: performance-research-template.md -->
