<!--
START OF: alternative-design-research-template.md
Purpose: Perform research on alternative design and write their implications for project decisions.
Update Frequency: Each time a new question arises that needs answer.
Location: docs/research/design-alternative/alternative-design-research-template.md
-->

# Alternative Design Research Template

statement

### Research

Aspects to be researched

#### Links

##### What was the impact of the linked resource



## Desicion


<!-- END OF: alternative-design-research-template.md -->
