<!--
START OF: tools-evaluation-research-template.md
Purpose: Perform research on tools and write their implications for project decisions.
Update Frequency: Each time a tools selection question needs answers.
Location: docs/research/performance/tools-evaluation-research-template.md
-->

# Tools Research Template

statement

### Research

Aspects to be researched

#### Links

##### Insights Gained

##### What was the impact of the linked resource



## Desicion


<!-- END OF: tools-evaluation-research-template.md -->
