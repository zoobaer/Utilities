<!--
START OF: docs/design-assets/ui-kits/wireframes/flowcharts/README.md
Purpose: Provide a comprehensive overview of each flowchart made.
Update Freqency: Each time a new flowchart is made.
Location: docs/design-assets/ui-kits/wireframes/flowcharts/README.md
-->

# Flowcharts

Each UI design flowchart asset will be recorded here.

## Flowchart Version
![image info]()
_Description:_
_Time Created:_
_Created By:_ [GitHub Link]()
_Note:_


> Flowchart Version follow this convention v#.##.### -> # means the current major version of the application. ## means the minor version. ### means a number assigned to the image (can be a letter.)

<!-- END OF: docs/design-assets/ui-kits/wireframes/flowcharts/README.md -->
