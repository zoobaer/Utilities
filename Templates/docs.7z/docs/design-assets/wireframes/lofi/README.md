<!--
START OF: docs/design-assets/ui-kits/wireframes/lofi/README.md
Purpose: Provide a comprehensive overview of each lofi made.
Update Freqency: Each time a major UI rework is made.
Location: docs/design-assets/ui-kits/wireframes/lofi/README.md
-->

# Lo-FI kit

Each UI design lo-fi asset will be recorded here.

## Lofi Version
![image info]()
_Description:_
_Time Created:_
_Created By:_ [GitHub Link]()
_Note:_


> Lofi Version follow this convention v#.##.### -> # means the current major version of the application. ## means the minor version. ### means a number assigned to the image (can be a letter.)

<!-- END OF: docs/design-assets/ui-kits/wireframes/lofi/README.md -->
