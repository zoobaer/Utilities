<!--
START OF: docs/design-assets/ui-kits/wireframes/sketches/README.md
Purpose: Provide a comprehensive overview of each sketch made.
Update Freqency: Each time a major UI rework is make.
Location: docs/design-assets/ui-kits/wireframes/sketches/README.md
-->

# Sketches

Each UI design sketches will be recorded here.

## Sketch Version
![image info]()
_Description:_
_Time Created:_
_Created By:_ [GitHub Link]()
_Note:_


> Sketch Version follow this convention v#.##.### -> # means the current major version of the application. ## means the minor version. ### means a number assigned to the image (can be a letter.)

<!-- END OF: docs/design-assets/ui-kits/wireframes/sketches/README.md -->
