<!--
START OF: style-guide.md
Purpose: Provide a comprehensive guide for preparing assets and design for this brand.
Update Frequency: Each time a branding syle is updated or changed
Location: docs/design-assets/branding/style-guide.md
-->

# Style Guide

A comprehensive guide for preparing design assets for this project.

### Colors


### Spacing


### Corners


### Logo


### Accessibility


### Tables


### Fonts


### Headings


### Paragraphs


### Images


### Videos


### Audio


### Title


<!-- END OF: style-guide.md -->
