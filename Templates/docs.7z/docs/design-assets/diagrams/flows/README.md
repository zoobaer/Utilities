<!--
START OF: docs/design-assets/diagrams/flows/README.md
Purpose: Store technical database diagrams.
Update Frequency: Whenever a new technical database diagram is created.
Location: docs/design-assets/diagrams/flows/README.md
-->


# Flows

Technical illustrations that show how the code is structured.

## [Template Image](flows/)

_Description:_ What kind of characteristics does this flowchart have.
_Time Added:_ <2025-06-27 Fri>
_Note:_


> Sync with planning docs.

<!-- END OF: docs/design-assets/diagrams/flows/README.md -->
